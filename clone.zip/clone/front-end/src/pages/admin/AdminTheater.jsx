"use client"

import TheaterManagement from "../../components/admin/TheaterManagement"

const AdminTheaters = () => {
  return <TheaterManagement />
}

export default AdminTheaters
